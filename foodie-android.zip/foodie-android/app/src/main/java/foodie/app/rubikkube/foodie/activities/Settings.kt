package foodie.app.rubikkube.foodie.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import foodie.app.rubikkube.foodie.R

class Settings : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
    }
}
