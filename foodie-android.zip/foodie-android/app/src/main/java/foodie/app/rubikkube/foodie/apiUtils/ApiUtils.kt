package foodie.app.rubikkube.foodie.apiUtils

/**
 * An utility object that acts as a Factory for the
 * REST API client.
 *
 * @author arish
 */
object ApiUtils {
    const val BASE_URL: String = "http://34.220.151.44"
//    const val BASE_URL: String = "http://arish-TECRA-R850:8000"

    fun getSOService(): SOService? {
        return RetrofitClient.getClient(this.BASE_URL)?.create(SOService::class.java)
    }
}
