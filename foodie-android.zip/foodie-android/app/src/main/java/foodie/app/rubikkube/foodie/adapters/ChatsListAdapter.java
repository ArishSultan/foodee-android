package foodie.app.rubikkube.foodie.adapters;

public class ChatsListAdapter {
}
